package com.example.sesilogin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class DashboardActivity : AppCompatActivity() {
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessionManager = SessionManager(this)

        if (!sessionManager.sudahLogin()) {
            kembaliLogin()
            return
        }

        setContentView(R.layout.activity_dashboard)
        findViewById<TextView>(R.id.tvName).text = sessionManager.getNama()
        findViewById<TextView>(R.id.tvEmail).text = sessionManager.getEmail()
        findViewById<TextView>(R.id.tvLoginTime).text = sessionManager.getWaktuLogin()
        findViewById<TextView>(R.id.tvGreeting).text = sapaanWaktu() + ", " + sessionManager.getNama() + "!"

        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            sessionManager.hapusSesi()
            kembaliLogin()
        }
    }

    private fun kembaliLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun sapaanWaktu(): String {
        return when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 5..10 -> "Selamat pagi"
            in 11..14 -> "Selamat siang"
            in 15..17 -> "Selamat sore"
            else -> "Selamat malam"
        }
    }
}
