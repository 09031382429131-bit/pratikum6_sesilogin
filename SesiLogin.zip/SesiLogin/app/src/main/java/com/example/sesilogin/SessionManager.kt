package com.example.sesilogin

import android.content.Context

class SessionManager(context: Context) {
    private val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun simpanSesi(nama: String, email: String, waktuLogin: String, ingatSaya: Boolean) {
        prefs.edit()
            .putBoolean(KEY_SUDAH_LOGIN, true)
            .putBoolean(KEY_INGAT_SAYA, ingatSaya)
            .putString(KEY_NAMA, nama)
            .putString(KEY_EMAIL, email)
            .putString(KEY_WAKTU_LOGIN, waktuLogin)
            .apply()
    }

    fun sudahLogin(): Boolean = prefs.getBoolean(KEY_SUDAH_LOGIN, false)
    fun ingatSaya(): Boolean = prefs.getBoolean(KEY_INGAT_SAYA, false)
    fun getNama(): String = prefs.getString(KEY_NAMA, "") ?: ""
    fun getEmail(): String = prefs.getString(KEY_EMAIL, "") ?: ""
    fun getWaktuLogin(): String = prefs.getString(KEY_WAKTU_LOGIN, "-") ?: "-"
    fun hapusSesi() { prefs.edit().clear().apply() }

    companion object {
        private const val PREF_NAME = "session_pref"
        private const val KEY_SUDAH_LOGIN = "sudah_login"
        private const val KEY_INGAT_SAYA = "ingat_saya"
        private const val KEY_NAMA = "nama"
        private const val KEY_EMAIL = "email"
        private const val KEY_WAKTU_LOGIN = "waktu_login"
    }
}
