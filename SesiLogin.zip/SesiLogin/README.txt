SESI LOGIN - PRAKTIKUM 6

Project Android Studio untuk memenuhi 10 ketentuan Praktikum 6.

Login demo:
Email    : rani@example.com
Password : 123456

Fitur wajib:
1. LoginActivity: email, sandi, Ingat saya, Masuk.
2. DashboardActivity: avatar, nama, email, waktu login terakhir.
3. Simpan sesi memakai SharedPreferences + apply().
4. LoginActivity memeriksa sesi pada onCreate().
5. Dashboard tidak dapat dibuka tanpa sesi.
6. Profil diambil dari SharedPreferences.
7. Tombol Keluar.
8. Logout menggunakan clear().apply().
9. Ingat saya menentukan apakah sesi otomatis dipakai pada pembukaan berikutnya.
10. Semua key dan proses sesi terpusat di SessionManager.

Catatan: Gradle Wrapper JAR tidak dapat disertakan dari environment pembuatan ini karena akses internet tidak tersedia. Android Studio dapat membuat/download wrapper saat Gradle Sync jika koneksi tersedia.
